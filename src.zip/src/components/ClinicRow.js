import React , {Component} from "react";
import axios from 'axios';
import "assets/css/bootstrap.min.css";
// reactstrap components
import { Button, Alert, Form, FormGroup, Input, Container, Row, Col, Modal, FormText } from "reactstrap";

// core components
import ExamplesNavbar from "components/Navbars/ExamplesNavbar.js";
import RegisterModal from "components/RegisterModal";
import ProfilePageHeader from 'components/Headers/ProfilePageHeader.js';


class ClinicRow extends Component {
    



  render() {
      return (
          
      )};
}